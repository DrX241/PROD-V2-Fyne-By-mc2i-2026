export type TeamMember = {
  id: string
  name: string
  role: string
  expertise: string[]
  avatar: string
  morale: number
  fatigue: number
  assigned: boolean
}

export type Resource = {
  id: string
  name: string
  description: string
  quantity: number
  cost: number
  type: "technical" | "human" | "financial"
}

export type ScenarioEvent = {
  id: string
  title: string
  description: string
  timeStamp: string
  severity: "low" | "medium" | "high" | "critical"
  read: boolean
}

export type Decision = {
  id: string
  title: string
  description: string
  options: DecisionOption[]
  deadline?: number // in seconds
  triggered: boolean
  resolved: boolean
}

export type DecisionOption = {
  id: string
  text: string
  consequences: {
    threatLevel?: number // -100 to 100
    reputation?: number // -100 to 100
    budget?: number // actual amount
    time?: number // in minutes
    morale?: number // -100 to 100
    events?: string[] // IDs of events to trigger
    decisions?: string[] // IDs of follow-up decisions to trigger
  }
}

export type Communication = {
  id: string
  from: string
  to: string
  subject: string
  content: string
  timeStamp: string
  read: boolean
  requiresResponse: boolean
  responseOptions?: {
    id: string
    text: string
    consequences: any
  }[]
}

export type GameState = {
  scenarioId: string
  scenarioTitle: string
  scenarioDescription: string
  currentTime: number // in minutes since start
  elapsedRealTime: number // in seconds of real time
  threatLevel: number // 0-100
  reputation: number // 0-100
  budget: number
  timeRemaining: number // in minutes
  gameSpeed: number // 1 = normal, 2 = fast, 0.5 = slow
  paused: boolean
  team: TeamMember[]
  resources: Resource[]
  events: ScenarioEvent[]
  decisions: Decision[]
  communications: Communication[]
  logs: {
    id: string
    text: string
    timeStamp: string
    category: "system" | "security" | "team" | "external"
  }[]
  score: {
    current: number
    breakdown: {
      category: string
      value: number
      description: string
    }[]
  }
  gameOver: boolean
  gameOverReason?: string
  gameWon: boolean
}

export const initialGameState: GameState = {
  scenarioId: "",
  scenarioTitle: "",
  scenarioDescription: "",
  currentTime: 0,
  elapsedRealTime: 0,
  threatLevel: 25,
  reputation: 100,
  budget: 500000,
  timeRemaining: 480, // 8 hours
  gameSpeed: 1,
  paused: true,
  team: [],
  resources: [],
  events: [],
  decisions: [],
  communications: [],
  logs: [],
  score: {
    current: 0,
    breakdown: [],
  },
  gameOver: false,
  gameWon: false,
}

export const scenarios = {
  "ransomware-attack": {
    id: "ransomware-attack",
    title: "Ransomware Attack",
    description:
      "Critical systems have been encrypted by ransomware. The attackers are demanding $2 million in cryptocurrency.",
    initialThreatLevel: 85,
    initialBudget: 750000,
    timeLimit: 480, // 8 hours
    initialEvents: [
      {
        id: "initial-detection",
        title: "Ransomware Detected",
        description: "Multiple servers have stopped responding. Users are reporting locked files with ransom notes.",
        timeStamp: "08:00 AM",
        severity: "critical",
        read: false,
      },
      {
        id: "ransom-note",
        title: "Ransom Note Received",
        description:
          "A ransom note has been found on affected systems demanding $2 million in Bitcoin within 48 hours.",
        timeStamp: "08:05 AM",
        severity: "high",
        read: false,
      },
    ],
    initialDecisions: [
      {
        id: "initial-response",
        title: "Initial Response Strategy",
        description: "How will you initially respond to the ransomware attack?",
        options: [
          {
            id: "isolate-systems",
            text: "Immediately isolate all affected systems from the network",
            consequences: {
              threatLevel: -10,
              time: 60,
              events: ["systems-isolated"],
            },
          },
          {
            id: "keep-online",
            text: "Keep systems online to investigate the attack vector",
            consequences: {
              threatLevel: 10,
              reputation: -5,
              events: ["attack-spread"],
            },
          },
          {
            id: "partial-isolation",
            text: "Selectively isolate critical systems while keeping others online for investigation",
            consequences: {
              threatLevel: -5,
              time: 30,
              events: ["partial-isolation"],
            },
          },
        ],
        triggered: true,
        resolved: false,
      },
    ],
    initialCommunications: [
      {
        id: "ceo-initial",
        from: "CEO",
        to: "CISO",
        subject: "Ransomware Situation",
        content:
          "I just heard about the ransomware attack. What's our exposure and how long until we're back online? The board is asking for immediate updates.",
        timeStamp: "08:15 AM",
        read: false,
        requiresResponse: true,
        responseOptions: [
          {
            id: "transparent",
            text: "Be transparent about the severity and uncertain timeline",
            consequences: {
              reputation: 5,
              events: ["ceo-appreciates-honesty"],
            },
          },
          {
            id: "reassuring",
            text: "Reassure that the situation is under control with minimal impact",
            consequences: {
              reputation: -10,
              events: ["ceo-discovers-truth"],
            },
          },
          {
            id: "technical",
            text: "Provide detailed technical explanation and realistic timeline",
            consequences: {
              reputation: 0,
              events: ["ceo-requests-simplification"],
            },
          },
        ],
      },
    ],
  },
  // Other scenarios would be defined here
}

export const teamMembers = [
  {
    id: "alex",
    name: "Alex Chen",
    role: "Security Operations Lead",
    expertise: ["Incident Response", "Threat Hunting", "SIEM Management"],
    avatar: "/placeholder.svg?height=50&width=50&query=security operations lead",
    morale: 100,
    fatigue: 0,
    assigned: false,
  },
  {
    id: "morgan",
    name: "Morgan Taylor",
    role: "Threat Intelligence Analyst",
    expertise: ["Threat Intelligence", "Malware Analysis", "Dark Web Monitoring"],
    avatar: "/placeholder.svg?height=50&width=50&query=threat intelligence analyst",
    morale: 100,
    fatigue: 0,
    assigned: false,
  },
  {
    id: "jordan",
    name: "Jordan Rivera",
    role: "Technical Security Specialist",
    expertise: ["Network Security", "Endpoint Protection", "Vulnerability Management"],
    avatar: "/placeholder.svg?height=50&width=50&query=technical security specialist",
    morale: 100,
    fatigue: 0,
    assigned: false,
  },
  {
    id: "sam",
    name: "Sam Washington",
    role: "Communications Director",
    expertise: ["Crisis Communications", "Stakeholder Management", "Regulatory Compliance"],
    avatar: "/placeholder.svg?height=50&width=50&query=communications director",
    morale: 100,
    fatigue: 0,
    assigned: false,
  },
]

export const initialResources = [
  {
    id: "forensic-analysts",
    name: "Forensic Analysts",
    description: "Specialists in digital forensics and malware analysis",
    quantity: 2,
    cost: 5000,
    type: "human",
  },
  {
    id: "incident-responders",
    name: "Incident Responders",
    description: "Experts in containing and remediating security incidents",
    quantity: 3,
    cost: 4000,
    type: "human",
  },
  {
    id: "backup-systems",
    name: "Backup Systems",
    description: "Offline backup systems that may contain clean copies of data",
    quantity: 1,
    cost: 50000,
    type: "technical",
  },
  {
    id: "endpoint-protection",
    name: "Enhanced Endpoint Protection",
    description: "Advanced endpoint security tools to detect and block malware",
    quantity: 0,
    cost: 25000,
    type: "technical",
  },
  {
    id: "pr-firm",
    name: "PR Crisis Management",
    description: "External PR firm specializing in cyber incident communications",
    quantity: 0,
    cost: 30000,
    type: "human",
  },
  {
    id: "legal-counsel",
    name: "Specialized Legal Counsel",
    description: "Lawyers specializing in cyber incidents and regulatory compliance",
    quantity: 1,
    cost: 20000,
    type: "human",
  },
  {
    id: "bitcoin",
    name: "Bitcoin for Ransom",
    description: "Cryptocurrency that could be used to pay ransom demands",
    quantity: 0,
    cost: 2000000,
    type: "financial",
  },
]

export function initializeGameState(scenarioId: string): GameState {
  const scenario = scenarios[scenarioId]
  if (!scenario) {
    throw new Error(`Scenario ${scenarioId} not found`)
  }

  return {
    ...initialGameState,
    scenarioId: scenario.id,
    scenarioTitle: scenario.title,
    scenarioDescription: scenario.description,
    threatLevel: scenario.initialThreatLevel || initialGameState.threatLevel,
    budget: scenario.initialBudget || initialGameState.budget,
    timeRemaining: scenario.timeLimit || initialGameState.timeRemaining,
    team: [...teamMembers],
    resources: [...initialResources],
    events: [...(scenario.initialEvents || [])],
    decisions: [...(scenario.initialDecisions || [])],
    communications: [...(scenario.initialCommunications || [])],
    logs: [
      {
        id: "game-start",
        text: `Scenario started: ${scenario.title}`,
        timeStamp: formatGameTime(0),
        category: "system",
      },
    ],
  }
}

export function formatGameTime(minutes: number): string {
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  const ampm = hours >= 12 ? "PM" : "AM"
  const formattedHours = hours % 12 || 12
  return `${formattedHours}:${mins.toString().padStart(2, "0")} ${ampm}`
}
