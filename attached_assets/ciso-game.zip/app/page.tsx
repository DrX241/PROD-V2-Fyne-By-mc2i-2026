import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-slate-900 to-slate-800 text-white">
      <header className="container mx-auto py-6">
        <h1 className="text-3xl font-bold tracking-tight text-cyan-400 md:text-4xl">CISO Challenge</h1>
        <p className="mt-2 text-slate-300">Cyber Crisis Management Simulation</p>
      </header>
      <main className="container mx-auto flex-1 py-8">
        <div className="grid gap-8 md:grid-cols-2">
          <Card className="bg-slate-800 border-slate-700 text-white">
            <CardHeader>
              <CardTitle className="text-cyan-400">Welcome, Chief Information Security Officer</CardTitle>
              <CardDescription className="text-slate-300">
                Test your skills in managing cyber security incidents
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                As the CISO, you'll face realistic cyber attack scenarios and work with your AI-powered security team to
                defend your organization. Make strategic decisions, allocate resources, and manage communications during
                the crisis.
              </p>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="flex flex-col items-center rounded-lg bg-slate-700 p-4">
                  <div className="text-2xl font-bold text-cyan-400">5+</div>
                  <div className="text-sm text-slate-300">Realistic Scenarios</div>
                </div>
                <div className="flex flex-col items-center rounded-lg bg-slate-700 p-4">
                  <div className="text-2xl font-bold text-cyan-400">4</div>
                  <div className="text-sm text-slate-300">AI Team Members</div>
                </div>
                <div className="flex flex-col items-center rounded-lg bg-slate-700 p-4">
                  <div className="text-2xl font-bold text-cyan-400">3</div>
                  <div className="text-sm text-slate-300">Difficulty Levels</div>
                </div>
                <div className="flex flex-col items-center rounded-lg bg-slate-700 p-4">
                  <div className="text-2xl font-bold text-cyan-400">∞</div>
                  <div className="text-sm text-slate-300">Possible Outcomes</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/game" className="w-full">
                <Button className="w-full bg-cyan-600 hover:bg-cyan-700">Start New Game</Button>
              </Link>
            </CardFooter>
          </Card>
          <Card className="bg-slate-800 border-slate-700 text-white">
            <CardHeader>
              <CardTitle className="text-cyan-400">How To Play</CardTitle>
              <CardDescription className="text-slate-300">Game mechanics and objectives</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-cyan-600 text-white">1</div>
                <div>
                  <h3 className="font-medium text-white">Assess the Situation</h3>
                  <p className="text-sm text-slate-300">
                    Analyze threat intelligence and determine the nature of the cyber attack.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-cyan-600 text-white">2</div>
                <div>
                  <h3 className="font-medium text-white">Coordinate Your Team</h3>
                  <p className="text-sm text-slate-300">
                    Assign tasks to your AI team members based on their expertise and the situation.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-cyan-600 text-white">3</div>
                <div>
                  <h3 className="font-medium text-white">Allocate Resources</h3>
                  <p className="text-sm text-slate-300">
                    Manage your limited budget and resources to effectively respond to the incident.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-cyan-600 text-white">4</div>
                <div>
                  <h3 className="font-medium text-white">Communicate Effectively</h3>
                  <p className="text-sm text-slate-300">
                    Decide what and when to communicate with stakeholders, the public, and authorities.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-cyan-600 text-white">5</div>
                <div>
                  <h3 className="font-medium text-white">Evaluate Performance</h3>
                  <p className="text-sm text-slate-300">
                    Receive a score based on your decisions and the outcome of the crisis.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Link href="/scenarios">
                <Button variant="outline" className="border-slate-600 text-white hover:bg-slate-700 hover:text-white">
                  View Scenarios
                </Button>
              </Link>
              <Link href="/team">
                <Button variant="outline" className="border-slate-600 text-white hover:bg-slate-700 hover:text-white">
                  Meet Your Team
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </main>
      <footer className="border-t border-slate-700 py-6 text-center text-sm text-slate-400">
        <div className="container mx-auto">
          CISO Challenge © {new Date().getFullYear()} | A Cyber Crisis Management Simulation
        </div>
      </footer>
    </div>
  )
}
